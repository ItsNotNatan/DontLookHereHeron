// server.js - Servidor de producao ATMLog (Express + PocketBase + Socket.io)
// Sobe 3 servicos no mesmo processo Node:
//   - API      (Express + WebSocket)  -> PORT_API     (padrao 3001)
//   - Client   (front publico SPA)    -> PORT_CLIENT  (padrao 8080)
//   - Admin    (painel SPA)           -> PORT_ADMIN   (padrao 8082)
// O banco e o PocketBase (porta 8090), iniciado pelo deploy.bat.
require('dotenv').config();
const express = require('express');
const cors = require('cors');
const path = require('path');
const fs = require('fs');
const http = require('http');
const { Server } = require('socket.io');

const PORT_API = process.env.PORT_API || 3001;
const PORT_CLIENT = process.env.PORT_CLIENT || 8080;
const PORT_ADMIN = process.env.PORT_ADMIN || 8082;

// ===================== 1. API (Express) =====================
const app = express();
app.use(cors());
app.use(express.json({ limit: '50mb' }));
app.use(express.urlencoded({ limit: '50mb', extended: true }));

// HTTP server + Socket.io (atualizacoes em tempo real)
const httpServer = http.createServer(app);
const io = new Server(httpServer, {
  cors: { origin: '*', methods: ['GET', 'POST', 'PUT', 'DELETE'] }
});
app.set('io', io);
io.on('connection', (socket) => {
  console.log(`🟢 Cliente tempo-real conectado: ${socket.id}`);
  socket.on('disconnect', () => console.log(`🔴 Cliente desconectado: ${socket.id}`));
});

// Apos qualquer mutacao (POST/PUT/DELETE) bem-sucedida, avisa o front-end pelo socket.
// Faz num unico lugar (em vez de editar cada controller) com base na rota.
app.use((req, res, next) => {
  if (['POST', 'PUT', 'DELETE', 'PATCH'].includes(req.method)) {
    res.on('finish', () => {
      if (res.statusCode < 200 || res.statusCode >= 300) return;
      const p = req.path || req.originalUrl || '';
      if (p.includes('/projetos')) io.emit('projetos_atualizados');
      else if (p.includes('/motivos')) io.emit('motivos_atualizados');
      else if (p.includes('/transportadoras')) io.emit('transportadoras_atualizadas');
      else if (p.includes('/usuarios')) io.emit('usuarios_atualizados');
      else if (p.includes('/veiculos')) io.emit('veiculos_atualizados');
      else if (p.includes('/locais')) io.emit('locais_atualizados');
      else if (p.includes('/transportes')) io.emit('transportes_atualizados');
    });
  }
  next();
});

// Rotas
app.use('/api/admin/projetos', require('./src/routes/projetoRoutes'));
app.use('/api/auth', require('./src/routes/authRoutes'));
app.use('/api', require('./src/routes/transporteRoutes'));
app.use('/api/admin/veiculos', require('./src/routes/veiculoRoutes'));
app.use('/api/admin/drive', require('./src/routes/driveRoutes'));
app.use('/api/admin/usuarios', require('./src/routes/usuarioRoutes'));
app.use('/api/admin/motivos', require('./src/routes/motivoRoutes'));
app.use('/api/admin/locais', require('./src/routes/localRoutes'));
app.use('/api/admin/transportadoras', require('./src/routes/transportadoraRoutes'));

app.get('/api/health', (req, res) => res.json({ ok: true, servico: 'ATMLog API', hora: new Date().toISOString() }));

httpServer.listen(PORT_API, '0.0.0.0', () => console.log(`🚀 API + WebSocket rodando na porta ${PORT_API}`));

// ===================== 2. Servir os Frontends (SPA) =====================
function servirSPA(nome, distDir, porta) {
  const spa = express();
  spa.use(cors());

  const indexPath = path.join(distDir, 'index.html');
  if (!fs.existsSync(indexPath)) {
    spa.use((req, res) => {
      res.status(503).send(
        `<h2>${nome}: build nao encontrado</h2>` +
        `<p>Rode <code>npm run build</code> no projeto do ${nome} e copie a pasta <b>dist</b> para:</p>` +
        `<pre>${distDir}</pre>`
      );
    });
    spa.listen(porta, '0.0.0.0', () => console.log(`⚠️  ${nome} na porta ${porta} (SEM build ainda - copie o dist)`));
    return;
  }

  spa.use(express.static(distDir));
  // Fallback SPA (Express 5): qualquer rota nao-arquivo devolve o index.html
  spa.use((req, res) => res.sendFile(indexPath));
  spa.listen(porta, '0.0.0.0', () => console.log(`🌐 ${nome} rodando na porta ${porta}`));
}

servirSPA('Client (publico)', path.join(__dirname, 'public', 'client'), PORT_CLIENT);
servirSPA('Admin (gestao)', path.join(__dirname, 'public', 'admin'), PORT_ADMIN);

// ===================== 3. Sincronizador Google Sheets =====================
if (process.env.GOOGLE_CLIENT_EMAIL) {
  const puxarDadosDaPlanilha = require('./src/services/syncPlanilha');
  puxarDadosDaPlanilha();
  setInterval(puxarDadosDaPlanilha, 120000); // a cada 2 min
  console.log('🔁 Sincronizacao do Google Sheets ATIVA (a cada 2 min).');
} else {
  console.log('⏸️  Sincronizacao do Google Sheets DESATIVADA (GOOGLE_CLIENT_EMAIL vazio).');
}
