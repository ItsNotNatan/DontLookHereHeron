// server.js - Servidor de producao ATMLog (Express + PocketBase)
// Sobe 3 servicos no mesmo processo Node:
//   - API      (Express)            -> PORT_API     (padrao 3001)
//   - Client   (front publico SPA)  -> PORT_CLIENT  (padrao 8080)
//   - Admin    (painel SPA)         -> PORT_ADMIN   (padrao 8082)
// O banco e o PocketBase (porta 8090), iniciado pelo deploy.bat.
require('dotenv').config();
const express = require('express');
const cors = require('cors');
const path = require('path');
const fs = require('fs');

const PORT_API = process.env.PORT_API || 3001;
const PORT_CLIENT = process.env.PORT_CLIENT || 8080;
const PORT_ADMIN = process.env.PORT_ADMIN || 8082;

// ===================== 1. API (Express) =====================
const app = express();
app.use(cors());
app.use(express.json({ limit: '50mb' }));
app.use(express.urlencoded({ limit: '50mb', extended: true }));

// Rotas
app.use('/api/admin/projetos', require('./src/routes/projetoRoutes'));
app.use('/api/auth', require('./src/routes/authRoutes'));
app.use('/api', require('./src/routes/transporteRoutes'));
app.use('/api/admin/veiculos', require('./src/routes/veiculoRoutes'));
app.use('/api/admin/drive', require('./src/routes/driveRoutes'));
app.use('/api/admin/usuarios', require('./src/routes/usuarioRoutes'));
app.use('/api/admin/motivos', require('./src/routes/motivoRoutes'));
app.use('/api/admin/locais', require('./src/routes/localRoutes'));
app.use('/api/admin/transportadoras', require('./src/routes/transportadoraRoutes'));

app.get('/api/health', (req, res) => res.json({ ok: true, servico: 'ATMLog API', hora: new Date().toISOString() }));

app.listen(PORT_API, '0.0.0.0', () => console.log(`🚀 API rodando na porta ${PORT_API}`));

// ===================== 2. Servir os Frontends (SPA) =====================
function servirSPA(nome, distDir, porta) {
  const spa = express();
  spa.use(cors());

  const indexPath = path.join(distDir, 'index.html');
  if (!fs.existsSync(indexPath)) {
    // Build ainda nao copiado: mostra um aviso amigavel em vez de quebrar.
    spa.use((req, res) => {
      res.status(503).send(
        `<h2>${nome}: build nao encontrado</h2>` +
        `<p>Rode <code>npm run build</code> no projeto do ${nome} e copie a pasta <b>dist</b> para:</p>` +
        `<pre>${distDir}</pre>`
      );
    });
    spa.listen(porta, '0.0.0.0', () => console.log(`⚠️  ${nome} na porta ${porta} (SEM build ainda - copie o dist)`));
    return;
  }

  spa.use(express.static(distDir));
  // Fallback SPA (Express 5): qualquer rota nao-arquivo devolve o index.html
  spa.use((req, res) => res.sendFile(indexPath));
  spa.listen(porta, '0.0.0.0', () => console.log(`🌐 ${nome} rodando na porta ${porta}`));
}

servirSPA('Client (publico)', path.join(__dirname, 'public', 'client'), PORT_CLIENT);
servirSPA('Admin (gestao)', path.join(__dirname, 'public', 'admin'), PORT_ADMIN);

// ===================== 3. Sincronizador Google Sheets =====================
if (process.env.GOOGLE_CLIENT_EMAIL) {
  const puxarDadosDaPlanilha = require('./src/services/syncPlanilha');
  puxarDadosDaPlanilha();
  setInterval(puxarDadosDaPlanilha, 120000); // a cada 2 min
  console.log('🔁 Sincronizacao do Google Sheets ATIVA (a cada 2 min).');
} else {
  console.log('⏸️  Sincronizacao do Google Sheets DESATIVADA (GOOGLE_CLIENT_EMAIL vazio).');
}
